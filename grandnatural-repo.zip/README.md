# Grandnatural website

Static one-file site (`index.html`) with images in `images/`. No build step.

- Main page: `/`
- References page: `/#referenciak`

## Deploy
- Netlify: drag the whole folder onto app.netlify.com, or connect this repo (build command empty, publish directory `.`).
- GitHub Pages: Settings -> Pages -> Deploy from branch `main`, folder `/ (root)`.
